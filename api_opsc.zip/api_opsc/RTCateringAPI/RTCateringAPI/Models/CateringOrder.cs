﻿
namespace RTCateringAPI.Models
{
    public class CateringOrder
    {
        public int Id { get; set; }

        public string OrderNumber { get; set; } = "";

        public int UserId { get; set; }

        public string EventDate { get; set; } = "";

        public int Guests { get; set; }

        public string OrderType { get; set; } = "";

        public string DeliveryAddress { get; set; } = "";

        public string Notes { get; set; } = "";

        public decimal Total { get; set; }

        public decimal AmountPaid { get; set; }

        public decimal Balance { get; set; }

        public string PaymentType { get; set; } = "";

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
