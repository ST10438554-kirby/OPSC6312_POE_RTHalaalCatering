﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RTCateringAPI.Data;
using RTCateringAPI.Models;

namespace RTCateringAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CateringOrdersController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public CateringOrdersController(ApplicationDbContext context)
        {
            _context = context;
        }

        // PLACE A NEW ORDER
        [HttpPost]
        public async Task<IActionResult> CreateOrder(
            [FromBody] CreateOrderRequest request)
        {
            var user = await _context.Users.FindAsync(request.UserId);

            if (user == null)
            {
                return NotFound(new
                {
                    message = "Customer account not found."
                });
            }

            if (string.IsNullOrWhiteSpace(request.OrderNumber) ||
                string.IsNullOrWhiteSpace(request.EventDate) ||
                request.Guests <= 0 ||
                request.Total <= 0)
            {
                return BadRequest(new
                {
                    message = "Please provide valid order details."
                });
            }

            var existingOrder = await _context.CateringOrders
                .AnyAsync(o => o.OrderNumber == request.OrderNumber);

            if (existingOrder)
            {
                return Conflict(new
                {
                    message = "Order number already exists."
                });
            }

            var order = new CateringOrder
            {
                OrderNumber = request.OrderNumber,
                UserId = request.UserId,
                EventDate = request.EventDate,
                Guests = request.Guests,
                OrderType = request.OrderType,
                DeliveryAddress = request.DeliveryAddress,
                Notes = request.Notes,
                Total = request.Total,
                AmountPaid = request.AmountPaid,
                Balance = request.Balance,
                PaymentType = request.PaymentType,
                CreatedAt = DateTime.UtcNow
            };

            _context.CateringOrders.Add(order);

            await _context.SaveChangesAsync();

            return Ok(new
            {
                message = "Order placed successfully.",
                orderId = order.Id,
                orderNumber = order.OrderNumber
            });
        }

        // GET CUSTOMER ORDERS
        [HttpGet("user/{userId}")]
        public async Task<IActionResult> GetUserOrders(int userId)
        {
            var user = await _context.Users.FindAsync(userId);

            if (user == null)
            {
                return NotFound(new
                {
                    message = "Customer not found."
                });
            }

            var orders = await _context.CateringOrders
                .Where(o => o.UserId == userId)
                .OrderByDescending(o => o.CreatedAt)
                .ToListAsync();

            return Ok(orders);
        }
    }

    public class CreateOrderRequest
    {
        public string OrderNumber { get; set; } = "";

        public int UserId { get; set; }

        public string EventDate { get; set; } = "";

        public int Guests { get; set; }

        public string OrderType { get; set; } = "";

        public string DeliveryAddress { get; set; } = "";

        public string Notes { get; set; } = "";

        public decimal Total { get; set; }

        public decimal AmountPaid { get; set; }

        public decimal Balance { get; set; }

        public string PaymentType { get; set; } = "";
    }
}
